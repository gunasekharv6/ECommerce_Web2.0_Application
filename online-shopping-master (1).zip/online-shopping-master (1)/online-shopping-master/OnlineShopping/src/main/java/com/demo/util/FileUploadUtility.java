package com.demo.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.demo.pojos.Product;


public class FileUploadUtility {


	private static final Path ABS_PATH = Paths.get("D:\\Classes\\Sem 3\\Web Tools\\assets");
	private static Path RELATIVE_PATH = null;
	
	
	public static void uploadFile(HttpServletRequest request, MultipartFile multipartFile, Product product) 
	{				
		// get the relative server path
		RELATIVE_PATH = Paths.get(request.getSession().getServletContext().getRealPath("/assets/images/"));
			
		
		// to make sure all the directory exists
		// create directories
//		if(!new File(ABS_PATH).exists()) {
//			// create the directories
//			new File(ABS_PATH).mkdirs();
//		}
//		
//		if(!new File(RELATIVE_PATH).exists()) {
//			// create the directories
//			new File(RELATIVE_PATH).mkdirs();
//		}
		
		try {
//			// server upload	
//			file.transferTo(new File(RELATIVE_PATH + code + ".jpg"));
//			// project directory upload
//			file.transferTo(new File(ABS_PATH + code + ".jpg"));
			System.out.println("INSIDE FILEUPLOAD UTILITY");
//			Path absPath = Paths.get(ABS_PATH + code + ".jpg");
//			Path relativePath = Paths.get(RELATIVE_PATH + code + ".jpg");
			

			

			
			
			if(!Files.exists(ABS_PATH)) {
				Files.createDirectories(ABS_PATH);
			}
			if(!Files.exists(RELATIVE_PATH)) {
				Files.createDirectories(RELATIVE_PATH);
			}
			
			
			String fileType=multipartFile.getContentType().split("/")[1];
			System.out.println("*****multipartFile.getContentType()***** :"+multipartFile.getContentType());
			InputStream is = multipartFile.getInputStream();
			
			product.setFile("product_"+product.getId()+"."+fileType);
			product.setByteImageArray(is.readAllBytes());
			
			
			Path absFilePath = ABS_PATH.resolve("product_"+product.getId()+"."+fileType);
			Path relativeFilePath = RELATIVE_PATH.resolve("product_"+product.getId()+"."+fileType);
			
			
            Files.copy(is, absFilePath, StandardCopyOption.REPLACE_EXISTING);
            Files.copy(is, relativeFilePath, StandardCopyOption.REPLACE_EXISTING);
			
		}
		catch(IOException ex) {
			ex.printStackTrace();
		}		
 	}
	
	
//	public static getFile(byte[] byteImageArray) {
//		
//	}
	
	
}
