package com.demo.controller;




import java.io.File;
import java.io.FileInputStream;
import java.util.List;

import javax.persistence.EntityExistsException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.hibernate.exception.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dao.CategoryDAO;
import com.demo.dao.ProductDAO;
import com.demo.exception.CategoryNotFoundException;
import com.demo.exception.ProductNotDeleteException;
import com.demo.exception.ProductNotFoundException;
import com.demo.pojos.Category;
import com.demo.pojos.Product;
import com.demo.validator.ProductValidator;


@Controller
@RequestMapping("/manage")
public class ManagementController {
	

	
	@Autowired
	private CategoryDAO categoryRepo;
	
	
	@Autowired
	private ProductDAO productRepo;
	
	
	@Autowired
	private ProductValidator validator;
	
	
	/*
	 * Method to load MANAGE ALL PRODUCTS page, or to show status AFTER new product submission, new category submission, product deletion requests
	 */
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public ModelAndView showManageProduct(@RequestParam(name="operation",required=false) String operation, HttpServletRequest request) {
		
		ModelAndView mv = new ModelAndView("page");
		
		mv.addObject("userClickManageProducts",true);
		mv.addObject("title","Manage Products");
		
		
		// Product instance is created to map to modelAttribute="product" in jsp form
		Product nProduct = new Product();
		
		nProduct.setSupplierId(1);
		nProduct.setActive(true);
		
		mv.addObject("product",nProduct);
		
		
		// Below is executed if this page is reached to show task status after a certain other task is completed
		if(operation!=null) {
			
			if(operation.equals("product")) {
				
				mv.addObject("message","Product Submitted successfully!");
			}
			else if(operation.equals("category")) {
				mv.addObject("message", "Category Submitted Successfully!");
			}
			else if(operation.equals("productdeletion")) {
				mv.addObject("message", "Product Deleted Successfully!");
			}
		}
		
//		request.setAttribute("adminProductList", productRepo.list());
//		request.getSession().setAttribute("adminProductList", productRepo.list());
		mv.addObject("adminProductList", productRepo.list());
		return mv;	
	}
	
	
	
	
	
	/*
	 * Method to load VIEW a single product so as to be able to EDIT it
	 */
	@RequestMapping(value="/{id}/product",method=RequestMethod.GET)
	public ModelAndView showEditProduct(@PathVariable int id, HttpServletRequest request) {
		
		ModelAndView mv = new ModelAndView("page");
		
//		mv.addObject("userClickManageProducts",true);
		mv.addObject("title","Manage Products");
		mv.addObject("userManageOneProduct", true);
		
		// fetch product from database
		Product nProduct = productRepo.get(id);
		// set the product fetch from database
		mv.addObject("product",nProduct);
//		HttpSession adminSession = request.getSession(true);
//		adminSession.setAttribute("adminProductList", productRepo.listActiveProducts());
		mv.addObject("adminProductList", productRepo.list());
		return mv;	
	}
	
	
	
	
	/*
	 * Method to manage new product submission, new category submission, product deletion requests
	 */
	//handling product submission
	@RequestMapping(value="/products", method=RequestMethod.POST)
	public String handleProductSubmission(@ModelAttribute("product") Product mProduct, BindingResult result, SessionStatus sessionStatus,
			Model model, HttpServletRequest request, @RequestParam("file") String filePath) {
		
		System.out.println("submit:**************"+request.getParameter("submit"));
		System.out.println("delete:**************"+request.getParameter("delete"));
		System.out.println("FilePath:**************"+filePath);
		System.out.println(mProduct);
		
		// For product Deletion request
		if(request.getParameter("delete")!= null) {
			try {
				System.out.println("ABOUT TO DELETE");
				Product product = productRepo.get(mProduct.getId());
				
				
				productRepo.delete(product);
				return "redirect:/manage/products?operation=productdeletion";
			}catch (ProductNotDeleteException e) {
				model.addAttribute("userClickManageProducts",true);
				model.addAttribute("title","Manage Products");
				model.addAttribute("message","Product cannot be Deleted as there are associated orders with this product!  You can still make the product Inactive");
				
				e.printStackTrace();
				return "page";
			}
		}
		
		// For product creation request		
		if(mProduct.getId() == 0) {
			validator.validate(mProduct, result);
		}
		
		// check if there are any errors
		if(result.hasErrors()) {
		 
			model.addAttribute("userClickManageProducts",true);
			model.addAttribute("title","Manage Products");
			
			model.addAttribute("message","Validation failed for Product Submission!");
			return "page";
		}
		
		
		// To handle File Upload
			
		if((filePath != null && !filePath.isEmpty()) || ((filePath==null || filePath.isEmpty()) && mProduct.getId() == 0)) {
			System.out.println("INSIDE file upload******filePath:"+filePath+", mProduct.getId(): "+mProduct.getId());
			File file;
	        if(filePath != null && !filePath.isEmpty()) {
	        	System.out.println("INSIDE if");
	            file = new File("D:\\Classes\\Sem 3\\Web Tools\\Help\\online-shopping-master (1)\\online-shopping-master\\OnlineShopping\\src\\main\\webapp\\assets\\images\\" + filePath);
	        } else {
	        	System.out.println("INSIDE else");
	            file = new File("D:\\Classes\\Sem 3\\Web Tools\\Help\\online-shopping-master (1)\\online-shopping-master\\OnlineShopping\\src\\main\\webapp\\assets\\images\\veggies.jpg");
	        }
	        byte[] bfile = new byte[(int) file.length()];
	        try {
	            FileInputStream fileInputStream = new FileInputStream(file);
	            fileInputStream.read(bfile);
	            fileInputStream.close();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        mProduct.setByteImageArray(bfile);	        
		}else {
			if(mProduct != null && mProduct.getId() != 0) {
				Product product = productRepo.get(mProduct.getId());
				mProduct.setByteImageArray(product.getByteImageArray());
			}
		}
    
        
		
		if(mProduct.getId() == 0) {
			//create a new product record
			try {
				productRepo.add(mProduct);
			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
		}
		else {
			//update a product record
			try {
//				Product product = productRepo.get(mProduct.getId());
				productRepo.update(mProduct);
			} catch (ProductNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		
		sessionStatus.setComplete();
		return "redirect:/manage/products?operation=product";
	
	}
	
	
	@RequestMapping(value = "/product/{id}/activation", method=RequestMethod.GET)
	@ResponseBody
	public String handleProductActivation(@PathVariable int id) {
		System.out.println("****************INSIDE handleProductActivation*************");
		// fetch the product from database and update activate or deactivate based on the value of active field
		Product product = productRepo.get(id);
		boolean isActive = product.isActive();
		product.setActive(!product.isActive());
		try {
			productRepo.update(product);
		} catch (ProductNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return (isActive)?"You have successfully Deactivated the product with id:" + product.getId() :
						"You have successfully Activated the product with id:" + product.getId();
	}
	
	
	// to handle category submission
	@RequestMapping(value="/category",method=RequestMethod.POST)
	public String handleCategorySubmission(@ModelAttribute Category category) throws CategoryNotFoundException {
		 
		System.out.println("*************TEST1************"+category);
		categoryRepo.add(category);
		
		return "redirect:/manage/products?operation=category";
	}
	
	
	
	//returning categories for all the request mapping
	@ModelAttribute("categories")
	public List<Category> getCategories() {
		
		return categoryRepo.list();
	}
	
	@ModelAttribute("category")
	public Category getCategory() {
		return new Category();	
	}
 }






//@RequestMapping(value="/category", method=RequestMethod.GET)
//public ModelAndView showManageCategory(@RequestParam(name="operation",required=false) String operation) {
//	
//	ModelAndView mv = new ModelAndView("page");
//	
//	mv.addObject("userClickManageCategories",true);
//	mv.addObject("title","Manage Categories");
//	
//	Product nProduct = new Product();
//	
//	nProduct.setSupplierId(1);
//	nProduct.setActive(true);
//	
//	mv.addObject("product",nProduct);
//	
//	if(operation!=null) {
//		
//		if(operation.equals("product")) {
//			
//			mv.addObject("message","Product Submitted successfully!");
//		}
//		else if(operation.equals("category")) {
//			mv.addObject("message", "Category Submitted Successfully!");
//		}
//	}
//	
//	return mv;	
//}

