package com.demo.exception;

import java.io.Serializable;

public class ProductNotFoundException extends Exception implements Serializable {

	public ProductNotFoundException(String message) {
        super(message);
    }

    public ProductNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
