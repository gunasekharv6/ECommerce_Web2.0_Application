package com.demo.pojos;

import java.util.HashMap;
import java.util.Map;

public class Store {

	private Map<Integer, Integer> productMap = new HashMap<>();
	
	
	public Store() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public void add(Product product, int count) {
		productMap.put(product.getId(), productMap.getOrDefault(product,0)+count);
	}
	
	public boolean delete(Product product, int count) {
		
		int value = productMap.get(product.getId());
		
		if(value<count) {
			return false;
		}
		productMap.put(product.getId(), value-count);
		return true;
	}
	
	
	
	public void add(int productId, int count) {
		productMap.put(productId, productMap.getOrDefault(productId,0)+count);
	}
	
	public boolean delete(int productId, int count) {
		
		int value = productMap.get(productId);
		
		if(value<count) {
			return false;
		}
		productMap.put(productId, value-count);
		return true;
	}
	
	
	
	public Map<Integer, Integer> getProductMap() {
		return productMap;
	}



	public void setProductMap(Map<Integer, Integer> productMap) {
		this.productMap = productMap;
	}
	
}
