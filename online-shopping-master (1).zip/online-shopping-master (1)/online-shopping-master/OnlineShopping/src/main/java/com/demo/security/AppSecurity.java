package com.demo.security;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.demo.pojos.User;

@Component
public class AppSecurity implements HandlerInterceptor {

    public Set<String> excludedUrl = new HashSet<String>() {
        {
            add("/login");
            add("/signup");
            add("/error");
        }
    };
	
	
   @Override
   public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
	   System.out.println("INSIDE preHandle");
	   
	   
		String url = request.getRequestURI();
		System.out.println("interceptor for url:"+url);
		if(excludedUrl.contains(url) || url.contains("/static") || url.contains("/resources")) {
			System.out.println("returned bypassed");
			return true;
		}
		else {
			HttpSession session = request.getSession(false);
			if(session == null) {
				System.out.println("no session found");
				RequestDispatcher dispatcher = request.getRequestDispatcher("/login");
				dispatcher.forward(request, response);
				return false;
			}
			else {
				System.out.println("session is present :"+session.getId());
				User currentUser = (User)session.getAttribute("user");
				if(currentUser == null) {
					RequestDispatcher dispatcher = request.getRequestDispatcher("/login");
					dispatcher.forward(request, response);
				}
				else {
					System.out.println("current user id:"+currentUser.getId());	
				}
				
				return true;
			}
		}
   }
}