package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.web.servlet.MultipartAutoConfiguration;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.demo.security.AdminFilter;

	

@SpringBootApplication
@EnableAutoConfiguration(exclude = {MultipartAutoConfiguration.class})
@ComponentScan({"com.demo.controller", "com.demo.dao", "com.demo.pojos", "com.demo.exception", "com.demo.repository", "com.demo.validator", "com.demo.security"})
public class OnlineShoppingApplication extends SpringBootServletInitializer implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(OnlineShoppingApplication.class, args);
	}
	
	
	@Bean(name = "multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
	    CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver();
	    multipartResolver.setMaxUploadSize(1000000000);
//	    multipartResolver.setMaxUploadSize(-1);
	    return multipartResolver;
	}
	
    @Bean
    public FilterRegistrationBean<AdminFilter> authenticationFilter() {
        
    	final FilterRegistrationBean<AdminFilter> filterRegistrationBean = new FilterRegistrationBean<>();
        
    	filterRegistrationBean.setFilter(new AdminFilter());
        filterRegistrationBean.addUrlPatterns("/manage/*");
        filterRegistrationBean.addUrlPatterns("/show/all/*");
        return filterRegistrationBean;
    }

}
