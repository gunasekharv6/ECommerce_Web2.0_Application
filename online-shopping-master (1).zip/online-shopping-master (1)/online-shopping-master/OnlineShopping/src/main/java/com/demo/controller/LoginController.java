package com.demo.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dao.UserDAO;
import com.demo.exception.UserException;
import com.demo.pojos.User;
import com.demo.validator.UserValidator;

@Controller
public class LoginController {
	@Autowired
	private UserValidator validator;
	@Autowired
	private UserDAO userDAO;
	
	@GetMapping("/login")
	public ModelAndView showLogin(User user, HttpServletRequest request) {
//		return "login-view";
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","Login");
		mv.addObject("userClickLogin",true);
		
		if(request.getParameter("signup")!= null && request.getParameter("signup").equals("success")) {
			mv.addObject("signupsuccessful", true);
		}
		
		if(request.getParameter("user_not_present") != null) {
			System.out.println(request.getAttribute("user_not_present"));
			mv.addObject("user_not_present", true);
		}
		return mv;
	}
	@PostMapping("/login")
	public String handleLogin(@ModelAttribute User user, BindingResult result, SessionStatus status, Model model, HttpServletRequest req) {
		validator.validateLogin(user, result);
		if(result.hasErrors()) {
			return "redirect:/login";
		}
		User savedUser;
		try {
			savedUser = userDAO.get(user.getEmail());
			if(savedUser == null || !savedUser.getPassword().equals(user.getPassword())) {
				System.out.println("authentication failed");

				return "redirect:/login?user_not_present=true";
			}
		} catch (UserException e) {
			e.printStackTrace();
			return "redirect:/login";
		}
		HttpSession session = req.getSession();
		session.setAttribute("user", savedUser);
		status.setComplete();
		model.addAttribute("user", savedUser );
		System.out.println("authentication success!!!");
		
		boolean isAdmin = savedUser.getRole() == 0?false:true;
		session.setAttribute("isAdmin", isAdmin);
		session.setAttribute("loggedIn", true);
		
		return savedUser.getRole() == 0?"redirect:/home":"redirect:/manage/products";
	}
	
	@GetMapping("/logout")
	public String doLogout(HttpServletRequest req, HttpSession session) {
//		HttpSession session = req.getSession(false);
		session.removeAttribute("user");
		session.invalidate();
		System.out.println("invalidating session:"+session.getId());
		return "redirect:/login";
	}
}

