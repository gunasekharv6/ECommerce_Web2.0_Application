package com.demo.controller;




import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dao.ProductDAO;
import com.demo.dao.UserDAO;
import com.demo.exception.ProductNotFoundException;
import com.demo.exception.UserException;
import com.demo.pojos.Cart;
import com.demo.pojos.Product;
import com.demo.pojos.User;
import com.demo.repository.ProductRepo;

@Controller
@RequestMapping("/cart")
public class CartController {

	
	@Autowired
	private ProductDAO productRepo;
	
	@Autowired
	private UserDAO userRepo;
	
	
	@GetMapping("")
	public ModelAndView cart(HttpServletRequest request, HttpSession userSession) {
		
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","Cart");
		mv.addObject("userClickCart",true);
		
		return mv;
	}
	
	@GetMapping("/add/{id}/product")
	@ResponseBody
	public int[] addToCart(HttpServletRequest request, HttpSession userSession, @PathVariable("id") int id) throws ProductNotFoundException {
		
		Product product = productRepo.get(id);
		
		Cart userCart = (Cart) userSession.getAttribute("userCart");
		
		if(userCart == null) {
			userCart = new Cart();
		}
		
			
		userCart.getCartItems().add(product.getId());		
		userSession.setAttribute("userCart", userCart);
		
		productRepo.list();
		
		System.out.println(product.getId() + "--"+ (productRepo.get(product.getId())));
		System.out.println(userCart.getCartItems());

//		return new int[] {addable,(product.getQuantity()-count)};
		return new int[] {1,0};
	}
	
	
	
	@PostMapping("")
	public ModelAndView removeFromCart(HttpServletRequest request, HttpSession userSession) throws ProductNotFoundException {
		System.out.println("INSIDE REMOVE CART ITEM CONTROLLER");
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","Cart");
		mv.addObject("userClickCart",true);
		
		String ids = request.getParameter("element"); 
		int id = Integer.parseInt(ids);
		Product product = productRepo.get(id);
		System.out.println("Hibernate Retrieved product--"+product);

		
		
//		HttpSession userSession = request.getSession();
		Cart userCart = (Cart) userSession.getAttribute("userCart");
		
		if(userCart == null) {
			System.out.println("USER CART IS EMPTY");
			mv.addObject("removed",false);
			return mv;
		}

		System.out.println("REMOVING CART ITEM "+product.getId());
		
		userCart.delete(product.getId());
		

		

//		userSession.removeAttribute("userCart");
		userSession.setAttribute("userCart", userCart);
		mv.addObject("removed",true);
		System.out.println(userCart.getCartItems());

		productRepo.list();
		
		return mv;
	}
	
	
	
//	@GetMapping("/count/{id}/product")
//	@ResponseBody
//	public int countSessionItems(HttpServletRequest request, HttpSession userSession, @PathVariable("id") int id) {
//		
//		Product product = productRepo.get(id);
//		
//		
//
//		Cart userCart = (Cart) userSession.getAttribute("userCart");
//		
//		if(userCart == null) {
//			userCart = new Cart();
//		}
//		return product.getQuantity();
//	}
//	
	
	@GetMapping("/checkout")
	public ModelAndView checkout(HttpServletRequest request, HttpSession userSession) throws ProductNotFoundException, UserException {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","Checkout");
		mv.addObject("userClickCheckout",true);
		
		System.out.println("INSIDE CHECKOUT CART");
//		HttpSession userSession = request.getSession();
		Cart userCart = (Cart) userSession.getAttribute("userCart");
//		productRepo.list();
		
		User sessionUser = (User) userSession.getAttribute("user");
		List<Product> orders = sessionUser.getOrders();
		
		sessionUser = userRepo.get(sessionUser.getEmail());
		
		for(int id : userCart.getCartItems()) {
			Product product = productRepo.get(id);
			
			if(!(product.getUsers().contains(sessionUser))){
				product.getUsers().add(sessionUser);
			}
			sessionUser.getOrders().add(product);
//			productRepo.update(product);
		}
		
		
		userRepo.update(sessionUser);
//		
//		
//		userRepo.update(sessionUser);
//		
//		
		userCart.setCartItems(new ArrayList<>());
		userSession.setAttribute("userCart", userCart);
		
		
		
//		userSession.removeAttribute("userCart");
//		userSession.invalidate();
		return mv;
	}
	
}
