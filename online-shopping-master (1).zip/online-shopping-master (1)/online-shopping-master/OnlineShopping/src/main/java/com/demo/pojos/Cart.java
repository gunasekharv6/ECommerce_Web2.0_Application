package com.demo.pojos;

import java.util.*;

import com.demo.dao.ProductDAO;
import com.demo.exception.ProductNotFoundException;
import com.demo.repository.ProductRepo;

public class Cart {

	private List<Integer> cartItems = new ArrayList<>();
	
	
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}


	public List<Integer> getCartItems() {
		return cartItems;
	}


	public void setCartItems(List<Integer> cartItems) {
		this.cartItems = cartItems;
	}
	
	
	public boolean add(int id) {
		return cartItems.add(id);
	}
	
	public boolean delete(int id) {
		
		int containedAt = -1;
		for(int i=0; i<cartItems.size(); i++) {
			if(cartItems.get(i)==id) {
//				doesContain = true;
				containedAt = i;
//				count++;
				break;
			}
		}
		System.out.println("Deleting " + id + "from cart items inside cart object");
		cartItems.remove(containedAt);
		
		return containedAt != -1;
	}
	
	


	@Override
	public String toString() {
		return "Cart [cartItems=" + cartItems + "]";
	}
	
	public List<Product> getProductList() throws ProductNotFoundException{
		ProductRepo productRepo = new ProductDAO();
		
		List<Product> list = new ArrayList<>();
		for(int i:cartItems) {
			list.add(productRepo.get(i));
		}
		return list;
	}

	
}
