package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dao.UserDAO;
import com.demo.exception.UserException;
import com.demo.pojos.User;
import com.demo.validator.UserValidator;

@Controller
public class SignUpController {
	@Autowired
	private UserValidator validator;
	@Autowired
	private UserDAO userDAO;
	
	@GetMapping("/signup")
	public ModelAndView showSignUp(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","SignUp");
		mv.addObject("userClickSignUp",true);
		
		if(request.getParameter("user") != null) {
			System.out.println(request.getAttribute("user"));
			mv.addObject("user_already_exists", true);
		}
		
		return mv;
	}
	@PostMapping("/signup")
	public String handleSignUp(@ModelAttribute User user, BindingResult result, SessionStatus status, Model model, HttpServletRequest request) {
		validator.validate(user, result);
		
		if(result.hasErrors()) {
			List<ObjectError> errs = result.getAllErrors();
			for(int i=0;i<errs.size();i++) {
				System.out.println(errs.get(i).getCode() +":"+ errs.get(i).getDefaultMessage());
			}
			return "redirect:/signup";
		}
		try {
			User savedUser = userDAO.get(user.getEmail());
			if(savedUser != null && savedUser.getEmail().equals(user.getEmail())) {
				model.addAttribute("message", "Email is already registered! Please using sign In link to Sign In");
				return "redirect:/signup?user=alreadyExists";
			}
		} catch (UserException e) {
			e.printStackTrace();
			return "redirect:/signup";
		}
		try {
			userDAO.create(user);
		} catch (UserException e) {
			e.printStackTrace();
			model.addAttribute("error", "Error while Registering! Please try again");
			return "redirect:/signup";			
		}
		status.setComplete();
		return "redirect:/login?signup=success";
	}
}
