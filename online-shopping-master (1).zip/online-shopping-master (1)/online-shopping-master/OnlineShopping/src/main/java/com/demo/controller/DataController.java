package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.pojos.Product;
import com.demo.repository.ProductRepo;

@RestController
@RequestMapping("/data")
public class DataController {
	
	@Autowired
	private ProductRepo productRepo;
	
	@GetMapping("/all/products")
//	@ResponseBody
	public List<Product> getAllProducts() {
		
		return productRepo.list();
				
	}
	
	@GetMapping("admin/all/products")
//	@ResponseBody
	public List<Product> getAllProductsForAdmin() {
		
		return productRepo.list();
				
	}
	
	@GetMapping("/category/{id}/products")
//	@ResponseBody
	public List<Product> getProductsByCategory(@PathVariable int id) {
		
		return productRepo.listActiveProductsByCategory(id);
				
	}

}
