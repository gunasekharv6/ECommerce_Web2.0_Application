package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.demo.dao.UserDAO;
import com.demo.exception.UserException;
import com.demo.pojos.Product;
import com.demo.pojos.User;

@Controller
public class OrderHistoryController {

	@Autowired
	UserDAO userDAO;
	
	
	@GetMapping("/orderhistory")
	public ModelAndView orderHistory(HttpServletRequest request, HttpSession userSession) throws UserException {
		ModelAndView mv = new ModelAndView("page");
		mv.addObject("title","Order History");
		mv.addObject("userClickOrderHistory",true);
		
		User sessionUser = (User) userSession.getAttribute("user");
		sessionUser = userDAO.get(sessionUser.getEmail());
		System.out.println(sessionUser.getOrders());
//		List<Product> productsOfUser = userDAO.userProductlist();
		request.setAttribute("productsOfUser", sessionUser.getOrders());
		return mv;
		
	}
}
