package com.demo.exception;

public class ProductNotDeleteException extends Exception{
		public ProductNotDeleteException(String message) {
	        super(message);
	    }

	    public ProductNotDeleteException(String message, Throwable cause) {
	        super(message, cause);
	    }
}
