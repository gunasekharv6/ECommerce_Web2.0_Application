package com.demo.pojos;

import java.util.Base64;
import java.util.List;
import java.util.UUID;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="product")
public class Product implements Comparable<Product>{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String code;
	
	@NotBlank(message = "Please enter the Product Name!")
	private String name;
	@NotBlank(message = "Please enter the Brand Name!")
	private String brand;

	@NotBlank(message = "Please enter the product description!")
	private String description;
	@Column(name = "unit_price")
	@Min(value=1, message="The Price cannot be less than 1")
	private double unitPrice;
	
	@Transient	
	private int quantity;
	
	@Column(name = "is_active")	
	private boolean active;
	
	@ManyToMany(mappedBy="orders")
	private List<User> users;
	
	@Column(name = "category_id")
	private int categoryId;

	@Transient
	private int supplierId;
	@Transient
	private int purchases;
	@Transient
	private int views;
	
	@Column(name = "profilePic")
	private String file;
	
	@Lob
	@Column(columnDefinition = "mediumblob")
	private byte[] byteImageArray;
	
	@Transient
	private String base;
	
	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}
	

	public byte[] getByteImageArray() {
		return byteImageArray;
	}

	public void setByteImageArray(byte[] byteImageArray) {
		this.byteImageArray = byteImageArray;
	}
	

	public String getBase() {
		if(byteImageArray!=null) {
			this.base = Base64.getEncoder().encodeToString(byteImageArray);	
		}		
		return base!=null?base:"";
	}

	public void setBase(String base) {
		this.base = base;
	}

	//default constructor 
	public Product() {
		
		this.code =  "PRD" + UUID.randomUUID().toString().substring(26).toUpperCase();
	}
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}
	
		
	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public int getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}
	public int getPurchases() {
		return purchases;
	}
	public void setPurchases(int purchases) {
		this.purchases = purchases;
	}
	public int getViews() {
		return views;
	}
	public void setViews(int views) {
		this.views = views;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", code=" + code + ", name=" + name + ", brand=" + brand + ", description="
				+ description + ", unitPrice=" + unitPrice + ", quantity=" + quantity + ", active=" + active
				+ ", categoryId=" + categoryId + ", supplierId=" + supplierId + ", purchases=" + purchases + ", views="
				+ views + "]";
	}

	@Override
	public int compareTo(Product o) {
		// TODO Auto-generated method stub
		return this.id-o.getId();
	}
	
}