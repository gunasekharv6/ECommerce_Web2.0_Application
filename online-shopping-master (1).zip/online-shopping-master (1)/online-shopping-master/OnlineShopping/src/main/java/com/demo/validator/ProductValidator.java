package com.demo.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.demo.pojos.Product;

@Component
public class ProductValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		// TODO Auto-generated method stub
		return Product.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
			
//		Product product = (Product) target;
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "error-name", "Name can't be empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "brand", "error-brand", "Brand can't be empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "error-description", "Description can't be empty");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "unitPrice", "error-unitPrice", "UnitPrice can't be empty");
        
        
		
		//whether file has been selected or not
//		if(product.getFile() == null || product.getFile().getOriginalFilename().equals("")) {
//			errors.rejectValue("file", null, "Please select an image file to upload!");
//			return;
//		}
		
//		if(!(product.getFile().getContentType().equals("image/jpeg") || 
//				product.getFile().getContentType().equals("image/png") ||
//				product.getFile().getContentType().equals("image/gif")
//				)) {
//			
//			 errors.rejectValue("file", null, "Please use only image file for upload!");
//			return;
//		}
	}

}
