package com.demo.repository;

import java.util.List;

import com.demo.exception.ProductNotDeleteException;
import com.demo.exception.ProductNotFoundException;
import com.demo.pojos.Category;
import com.demo.pojos.Product;


public interface ProductRepo {

	// CRUD Methods
	Product get(int productId) throws ProductNotFoundException;
	List<Product> list();	
	boolean add(Product product) throws ProductNotFoundException;
	boolean update(Product product) throws ProductNotFoundException;
	boolean delete(Product product) throws ProductNotDeleteException;
	List<Product> getLst();
	
	// business methods
	List<Product> listActiveProducts();	
	List<Product> listActiveProductsByCategory(int categoryId);
	List<Product> getLatestActiveProducts(int count);
	List<Product> list(Category category);
}
