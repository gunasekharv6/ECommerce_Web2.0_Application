package com.demo.interceptor;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class AuthenticationInterceptor implements HandlerInterceptor {

    public Set<String> excludedUrl = new HashSet<String>() {
        {
            add("/login");
            add("/signup");
        }
    };

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!excludedUrl.contains(request.getRequestURI())) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                return true;
            } else {
                response.sendRedirect("/login");
            }
        }
        return true;
    }
}
